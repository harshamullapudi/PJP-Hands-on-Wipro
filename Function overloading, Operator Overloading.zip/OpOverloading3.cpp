#include <bits/stdc++.h>
using namespace std;
class String{
    private:
    string s;
    public:
    String(const string& s1): s(s1){}
    char operator[](int n){
        char chars[1024];
        strcpy(chars,s.c_str());
        return chars[n];
    }
};
int main()
{
    String s("abcd");
    char ch;
    ch=s[0];
    cout<<ch;

    return 0;
}
