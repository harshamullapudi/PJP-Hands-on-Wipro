
#include <bits/stdc++.h>
using namespace std;
class ASCII_Convert{
    private:
    char A[10];
    int B[10];
    public:
    void put(){
        for(int i=0;i<10;i++){
            cout<<B[i]<<" ";
        }
    }
    void get(){
        for(int i=0;i<10;i++){
            cin>>A[i];
            int k=int(A[i]);
            B[i]=k;
        }
    }
};
int main()
{
    ASCII_Convert a;
    a.get();
    a.put();
    return 0;
}

