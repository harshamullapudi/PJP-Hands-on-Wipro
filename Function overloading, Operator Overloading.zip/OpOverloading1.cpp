#include <bits/stdc++.h>
using namespace std;
 class Date{
     private:
     int day;
     int month;
     int year;
     public:
     Date(){
         day=0;
         month=0;
         year=0;
     }
     Date(int day1,int month1,int year1){
         day=day1;
         month=month1;
         year=year1;
     }
     void print(){
         cout<<day<<"-"<<month<<"-"<<year<<endl;
     }
     friend Date operator+(Date &, int);
     friend Date operator-(Date &, int);
 };
 
 Date operator+(Date &d1, int n){
     d1.day+=n;
     return d1;
     
 }
 Date operator-(Date &d1, int n){
     d1.day-=n;
     return d1;
     
 }
 int main(){
     Date d1(20,5,2000);
     Date d2=d1+1;
     d2.print();
     Date d3=d1-1;
     d3.print();
     return 0;
     
     
 }
