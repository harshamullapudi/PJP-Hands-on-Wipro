#include <iostream>
using namespace std;
void swap(float a,float b){
    float temp=a;
    a=b;
    b=temp;
    cout<<"floatswap: "<<a<<" "<<b<<endl;
}
void swap(double a,double b){
    double temp=a;
    a=b;
    b=temp;
    cout<<"doubleswap: "<<a<<" "<<b<<endl;
}
void swap(long a,long b){
    long temp=a;
    a=b;
    b=temp;
    cout<<"longswap: "<<a<<" "<<b<<endl;
}
int main(){
    swap(100000000000000,3);
    swap(2.4,7.5);
    return 0;
}

