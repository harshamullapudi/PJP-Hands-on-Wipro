#include <bits/stdc++.h>
using namespace std;
 class Date{
     private:
     int day;
     int month;
     int year;
     public:
     Date(){
         day=0;
         month=0;
         year=0;
     }
     Date(int day1,int month1,int year1){
         day=day1;
         month=month1;
         year=year1;
     }
     void print(){
         cout<<day<<"-"<<month<<"-"<<year<<endl;
     }
     friend Date operator++(Date &);
     friend Date operator--(Date &);
     friend Date operator++(Date &, int);
     friend Date operator--(Date &, int);
 };
 
 Date operator++(Date &d1){
     d1.day=++d1.day;
     return d1;
     
 }
 Date operator--(Date &d1){
     d1.day=--d1.day;
     return d1;
     
 }
 Date operator++(Date &d1, int n){
     d1.day=d1.day++;
     return d1;
     
 }
 Date operator--(Date &d1, int n){
     d1.day=d1.day--;
     return d1;
     
 }
 int main(){
     Date d1(31,1,2010);
     Date d2(1,10,2005);
     Date d5=--d2;
     d5.print();
     Date d3=++d1;
     d3.print();
     d3=d1++;
     d3.print();
     Date d4=d2--;
     d4.print();
     return 0;
     
     
 }
