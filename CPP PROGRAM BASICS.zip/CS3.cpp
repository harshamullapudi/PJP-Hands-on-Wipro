#include <iostream>
using namespace std;

int main() {
    int a;
    cout<<"Enter Number: "<<endl;
    cin>>a;
    int p=a/1000;
    int q=a/200;
    int r=a/100;
    cout << "Cashier gives you 1000 currency notes of "<<p<<endl<<"OR"<<endl<<"200 currency notes of "<<q<<endl<<"OR"<<endl<<"100 currency notes of "<<r;
    return 0;
}
