#include<iostream.h>
#include<conio.h>
 
void main()
{
    int n,f=1,i=1;
    clrscr();
     
    cout<<"\n Enter The Number:";
    cin>>n;
    do
    {
        f=f*i;
        i++;
    }while(i<=n);
     
    cout<<"\n The Factorial of "<<n<<" is "<<f;
    getch();
}
