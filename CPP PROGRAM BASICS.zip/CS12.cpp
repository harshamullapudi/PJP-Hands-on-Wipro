#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int n;
    char ch;
    scanf("%d\n",&n);
    scanf("%c",&ch);
    
    for(int i=1;i<=n;i++){
        for(int k=n-i;k>0;k--){
            cout<<" ";
        }
        for(int j=1;j<=i;j++){
            cout<<ch<<" ";
        }
        cout<<endl;
    }
    
    
    return 0;
}
