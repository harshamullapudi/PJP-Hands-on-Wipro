#include <iostream>
using namespace std;

int main() {
    int a;
    cout<<"Enter Number: "<<endl;
    cin>>a;
    if(a>0)
    cout<<a<<" is a positive number";
    else if(a<0)
    cout<<a<<" is a negativenumber";
    else
    cout<<a<<" is neither negative nor positive";
    return 0;
}
