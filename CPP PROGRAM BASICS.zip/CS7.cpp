#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int n;
    int count=0;
    scanf("%d", &n);
    if(n==0||n==1){
        printf("%d is neither prime nor composite",n);
    }
    //int count=0;
    for(int i=2;i<sqrt(n);i++){
        if(n%i==0)
        count++;
    }
    if(count==0)
    printf("%d is a prime number",n);
    else
    printf("%d is not a prime number",n);
    
    
    
    return 0;
}
