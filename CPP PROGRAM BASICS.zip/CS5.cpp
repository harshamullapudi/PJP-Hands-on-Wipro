#include <iostream>
using namespace std;

int main() {
    int a;
    cout<<"Enter Number: "<<endl;
    cin>>a;
    int sum=0;
    while(a>0){
        int r=a%10;
        sum=sum*10+r;
        a/=10;
    }
    cout<<sum;
    return 0;
