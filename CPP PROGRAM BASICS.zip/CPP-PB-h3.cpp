#include<iostream>
using namespace std;
int main(){
float a,b,c,d,e;
cout<<"Enter any floating point numbers: "<<endl;
cin>>a>>b>>c>>d>>e;
cout<<"Inputs are: "<<a<<b<<c<<d<<e<<endl;
return 0;
}
