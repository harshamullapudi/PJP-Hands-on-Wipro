#include <iostream>
using namespace std;

int main() {
    int a=5;
    a++;
    cout << a;

    return 0;
}
