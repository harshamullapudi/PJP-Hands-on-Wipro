#include <iostream>
using namespace std;

int main() {
    string a;
    cout<<"Enter Number: "<<endl;
    cin>>a;
    int sum=0;
    for(int i=0;i<a.length();i++){
        int k=(int)a[i];
        if(k==9){
            a[i]='0';
        }
        else{
            k++;
            char p=(char)k;
            a[i]=p;
        }
    }
        
    
    
    cout << a;
    

    return 0;
}
