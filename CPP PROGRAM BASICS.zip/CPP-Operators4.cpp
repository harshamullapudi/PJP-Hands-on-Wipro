#include <iostream>
using namespace std;

int main() {
    int a,b,GREATER;
    cin>>a>>b;
    a>b?GREATER=a:GREATER=b;
    cout << GREATER;

    return 0;
}
