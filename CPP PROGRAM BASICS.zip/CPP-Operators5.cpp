#include <iostream>
using namespace std;

int main() {
    int a,b;
    cout<<"Enter the numbers: "<<endl;
    cin>>a>>b;
    int p=a+b;
    int q=a-b;
    cout << "Sum of the two numbers is "<<p<<endl;
    cout << "Difference of the two numbers is "<<q<<endl;

    return 0;
}
