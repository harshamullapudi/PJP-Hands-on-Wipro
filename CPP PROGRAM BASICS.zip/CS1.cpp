#include <iostream>
using namespace std;

int main() {
    int a;
    cout<<"Enter Seconds: "<<endl;
    cin>>a;
    unsigned int p=a/3600;
    int b=a%3600;
    int q=b/60;
    int c=b%60;
    cout << "Time is "<<p<<" hrs "<<q<<" min "<<c<<" secs"<<endl;
    

    return 0;
}
