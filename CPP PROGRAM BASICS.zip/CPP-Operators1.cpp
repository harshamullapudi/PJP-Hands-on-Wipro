#include <iostream>
using namespace std;
int main(){
  int a,b,c,d,e;
  cout<<"Enter any 5 Integers: ";
  cin>>a>>b>>c>>d>>e;
  int k=(a+b+c+d+e)/5;
  cout<<k<<endl;
  return 0;
}
