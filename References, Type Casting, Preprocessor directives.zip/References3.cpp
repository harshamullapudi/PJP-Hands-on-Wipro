// code with error rectified

#include<bits/stdc++.h>
using namespace std;
void test (string str)
{
  cout << str;
} 
main ()
{
    
  test ("success");
}


