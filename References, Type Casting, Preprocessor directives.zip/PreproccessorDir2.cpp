
#include<bits/stdc++.h>
using namespace std;

#define CHECK(a)  ((a%2==0)?1: 0)
int main()
{
    int x;
    cout<<"Enter the Number: ";
    cin>>x;
    if(CHECK(x)){
        cout<<"The given number is even ";
        
    }
    else{
        cout<<"The given number is odd ";
    }
    return 0;
}

