#include<bits/stdc++.h>
using namespace std;

#define MAX 50
int main(){
    #if MAX>45
        cout<<"YES";
    
    #else
        cout<<"NO";
    
    #endif
}
