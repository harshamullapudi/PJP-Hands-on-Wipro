
#include<bits/stdc++.h>
using namespace std;

#define CASE_CHANGE(str){int ln = str.length();for (int i = 0; i < ln; i++) {if (str[i] >= 'a' && str[i] <= 'z')str[i] = str[i] - 32;else if (str[i] >= 'A' && str[i] <= 'Z')str[i] = str[i] + 32;}}
 
int main()
{
    string str;
 
    cout<<"Enter the string: ";
     cin>>str;
     CASE_CHANGE(str);
 
    cout << str;
    return 0;
}
