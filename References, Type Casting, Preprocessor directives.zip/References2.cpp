
#include <bits/stdc++.h>
using namespace std;

void myswap(int i,int j){
    int temp=i;
    i=j;
    j=temp;
}
main ()
{
  int i, j;
  cout << "Enter two numbers : ";
  cin >> i >> j;
  system ("clear");
  cout << "\nBefore Swapping :\n";
  cout << " i : " << i << "\t" << "j : " << j << endl;
  myswap (i, j);
  cout << "\nAfter Swapping :\n";
  cout << " i : " << i << "\t" << "j : " << j << endl;
}

