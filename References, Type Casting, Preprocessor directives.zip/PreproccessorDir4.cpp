
#include<bits/stdc++.h>
using namespace std;

#define DIVIDE_BY_TWO(y)(y=y>>1)
#define MULTIPLY_BY_TWO(y)(y=y*2)
int main()
{
    int x,y;
    cout<<"Enter x: ";
    cin>>x;
    int k=x;
    MULTIPLY_BY_TWO(x);
    cout<<"Multiply by two is ";
    cout<<x;
    cout<<"\n";
    DIVIDE_BY_TWO(k);
    cout<<"Divide by two is ";
    cout<<k;

    return 0;
}

