
#include <bits/stdc++.h>
using namespace std;
void func(int *arr, int m, int n)   
{
    cout<<"The Array is: "<<endl;
    for (int i=0; i<m; i++)
    {
       for (int j=0; j<n; j++)
       {
          cout<<*((arr+i*n) + j)<<" ";    
       }
       cout<<"\n";
    }
}

int main()
{
    int rows,cols;
    cout<<"Enter rows and cols: ";
    cin>>rows>>cols;
    int arr[rows][cols];
    cout<<"Enter elements: ";
    for(int i=0;i<rows;i++){
        for(int j=0;j<cols;j++){
            cin>>arr[i][j];
        }
    }
   
    func((int*)arr, rows, cols);         
    return 0;
}
