
#include <bits/stdc++.h>
using namespace std;

int GetVowelCount(char* s){
    int len;
    while(*s!='\0'){
        if(*s=='a'||*s=='A'||*s=='e'||*s=='E'||*s=='i'||*s=='I'||*s=='o'||*s=='O'||*s=='u'||*s=='U'){
            len++;
            
        }
        *s++;
    }
    return len;
    
}

int main()
{
    char s[50];
    for(int i=0; ;i++){
    
        cin>>s;
        int len=GetVowelCount(s);
        if(len>=3)
        cout<<s<<"  -- "<<len<<endl;
        
    }
        
    return 0;
}

