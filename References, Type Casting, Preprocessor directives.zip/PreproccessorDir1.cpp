
#include<bits/stdc++.h>
using namespace std;

#define SWAP(a,b){int temp=a;a=b;b=temp;}
int main()
{
    int x,y;
    cout<<"Enter 2 Numbers: ";
    cin>>x>>y;
    SWAP(x,y);
    cout<<"Swapped numbers are: ";
    cout<<x<<" "<<y;

    return 0;
}

