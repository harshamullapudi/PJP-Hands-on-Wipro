#include<fstream>
#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main(){
   ifstream obj1;
   ofstream obj2("student_formatted.txt");
   obj1.open("student_unformatted.txt");
   string line;
   while(getline(obj1,line)){
   string st=line;
      stringstream ss(st);
      string s1;
      while(ss>>s1){
         obj2<<setw(10)<<s1;
      }
      obj2<<"\n"; 
   }
   obj1.close();
   obj2.close();
   return 0;
}
