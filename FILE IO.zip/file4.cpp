#include <bits/stdc++.h>
using namespace std;
int main(){
    ifstream rf("Text.txt", ios::ate);
    ofstream wf;
    wf.open("reverseText.txt");
    char ch;
    streampos size=rf.tellg();
    rf.seekg(0, ios::end);
    for(int i=0;i<=size;i++){
        rf.seekg(-i, ios::end);
        rf.get(ch);
        wf<<ch;
    }
    return 0;
    
}
