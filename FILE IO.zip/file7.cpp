#include<bits/stdc++.h>
using namespace std;
struct Employee{
	int eno;
	string name;
	string job;
	double salary;
	int depno;
};
int main(){
	Employee e[10];
	fstream myfile;
	myfile.open("employee_db.txt",ios::out);
	if(!myfile)
   {
       cout<<"Error in creating file!!!";
       return 0;
   }
	for(int i=0;i<10;i++){
		cout<<"Enter emp"<<i<<" number: ";
		cin>>e[i].eno;
		myfile<<e[i].eno<<" ";
		cin.ignore();
		cout<<"Enter emp"<<i<<" name: ";
		getline(cin,e[i].name);
		myfile<<e[i].name<<" ";
		cout<<"Enter emp"<<i<<" job: ";
		getline(cin,e[i].job);
		myfile<<e[i].job<<" ";
		cout<<"Enter emp"<<i<<" salary: ";
		cin>>e[i].salary;
		myfile<<e[i].salary<<" ";
                cout<<"Enter emp"<<i<<" depno: ";
		cin>>e[i].depno;
		myfile<<e[i].depno;
        myfile<<endl;
	}
	int search;
	cout<<"*****************************"<<endl;
	cout<<"Enter Emp no for details: ";
	cin>>search;
	bool valid =false;
	for(int i=0;i<10;i++){
		if(e[i].eno==search){
		        valid=true;
			cout<<"Emp no: "<<e[i].eno<<endl;
			cout<<"Emp Name: "<<e[i].name<<endl;
			cout<<"Emp Job: "<<e[i].job<<endl;
			cout<<"Emp salary: "<<e[i].salary<<endl;
			cout<<"Emp dep no: "<<e[i].depno<<endl;
		}
	}
	if(!valid){
	     cout<<"No data found";
	}
	return 0;
}
