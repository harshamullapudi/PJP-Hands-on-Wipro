#include <bits/stdc++.h>
using namespace std;
int main(){
    string readf, writef;
    cout<<"Enter input file: ";
    getline(cin,readf);
    cout<<"Enter output file: ";
    getline(cin,writef);
    ifstream rf;
    ofstream wf;
    rf.open(readf);
    wf.open(writef);
    string line;
    int i=0;
    while(getline(rf,line)){
        wf<<line<<endl;
        i++;
    }
    return 0;
}
