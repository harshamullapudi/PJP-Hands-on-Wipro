#include <bits/stdc++.h>
using namespace std;
class Vector{
    public:
    int A[10];
    public:
    Vector(){
        for(int i=0;i<10;i++){
            A[i]=0;
        }
    }
    Vector(int* arr){
        for(int i=0;i<10;i++){
            A[i]=arr[i];
        }
    }
    friend ostream & operator <<(ostream &out, const Vector &v);
    friend istream & operator >>(istream &in, const Vector &v);
    
};
ostream & operator <<(ostream &out, const Vector &v){
    for(int i=0;i<10;i++){
        out<<v.A[i]<<" ";
    }
    return out;
}
istream & operator >>(istream &in,  Vector &v){
    for(int i=0;i<10;i++){
            in>>v.A[i];
        }
    return in;
}
int main(){
    fstream fin;
    fstream fout;
    fin.open("Read.txt", ios::in );
    fout.open("Write.txt", ios::out);
    Vector v1;
    fin>>v1;
    fout<<v1;
    
    return 0;
    
}
