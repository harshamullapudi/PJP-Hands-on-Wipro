#include <bits/stdc++.h>
using namespace std;
class Message{
    public:
    char M[50];
    public:
    Message(){
        M[0]='\0';
    }
    Message(char* arr){
        strcpy(M,arr);
    }
    friend ostream & operator <<(ostream &out, const Message &M);
    
};
ostream & operator <<(ostream &out, const Message &M){
    out<<M;
    return out;
}
int main(){
    fstream fin;
    float f=9.7;
    int i=45;
    char c='c';
    fin.open("IMP_Messagestxt", ios::in );
    char msg[50];
    fin.getline(msg,50);
    Message M(msg);
    cout<< i << f << M << c ;
    return 0;
    
}
