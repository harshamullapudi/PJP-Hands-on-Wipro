#include<bits/stdc++.h>
using namespace std;
int main(){
    string s;
    cout<<"Enter the string to be searched: ";
    getline(cin,s);
    string filename;
    cout<<"Enter the name of the file in which the string has to be searched: ";
    getline(cin,filename);
    ifstream myfile;
    myfile.open(filename);
    string line;
    int i=0;
    bool valid=false;
    while(getline(myfile,line)){
        if(line.find(s,0)!=string::npos){
            valid=true;
            cout<<"STRING PRESENT"<<endl;
            break;
        }
        i++;
    }
    if(!valid){
        cout<<"STRING not PRESENT"<<endl;
    }
    return 0;
}
