#include <iostream>
using namespace std;

int main() {
    int n;
    int k,p;
    int arr[n];
    cout<<"Enter the size of an array: " ;
    scanf("%d",&n);
    cout<<"enter the elements of an array: "<<endl;
    for(int i=0;i<n;i++){
        scanf("%d/n",&arr[i]);
    }
    printf("Enter the element to search: ");
    scanf("%d",&k);
    for(int i=0;i<n;i++){
        if(arr[i]==k){
            p=i;
            break;
        }
    }
    if(p)
    cout << "!!!Element not Found!!!";
    else
    cout<<"***Element "<<k<<" found at its index is "<<p<<" ***";

    return 0;
}
