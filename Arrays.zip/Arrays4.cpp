#include<iostream>
    using namespace std;
    int main ()
    {
        int arr[10], n, i, max, min;
        cout << "Enter the number of elements of the array : ";
        cin >> n;
        cout << "Enter the numbers : ";
        for (i = 0; i < n; i++)
            cin >> arr[i];
        max = arr[0];
        for (i = 0; i < n; i++)
        {
           if (max < arr[i])
                max = arr[i];
        }
        cout << "Largest element is : " << max;
        return 0;
    }
