#include <iostream>
using namespace std;
 
int main()
{
    int arr[20];
    int size=20;
    int i, j, temp;
    
    int sum=0;
    int count=0;
    cout<<"Enter the numbers "<<endl;
    for(i=0; i<size; i++)
    {
        cin>>arr[i];
    }
    for(i=0; i<size; i++)
    {
        if(arr[i]%2==0){
            count++;
            sum+=arr[i];
        }
    }
    cout<<"Sum af all values of even numbers is: "<<sum<<endl;
    cout<<"Number of even numbers present in array is: "<<count<<endl;
    return 0;
}
