#include <iostream>
#include<iomanip>
using namespace std;

int main() {
    int n;
    int sum=0;
    float avg;
    int arr[n];
    cout<<"Enter the size of an array" <<endl;
    scanf("%d",&n);
    cout<<"Enter "<<n<< " numbers" <<endl;
    for(int i=0;i<n;i++){
        scanf("%d/n",&arr[i]);
    }
    for(int i=0;i<n;i++){
    sum+=arr[i];
    }
    avg=(float)sum/n;
    cout<<"Sum of all elements in the array is "<<sum<<endl;
    cout<<fixed<<setprecision(2)<<"Average of all input numbers = "<<avg<< endl;
    
    
    return 0;
}
