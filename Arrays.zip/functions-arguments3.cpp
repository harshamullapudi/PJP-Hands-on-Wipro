#include <iostream>
#include<bits/stdc++.h>
#include<cmath>
#include<vector>

using namespace std;

int fac(int n){
    if (n>=1)
        return n*fac(n-1);
    else
        return 1;
}

 
int main()
{
    int n;
    cout<<"Enter a positive integer: ";
    cin>>n;
    int k=fac(n);
    cout<<"Factorial of "<<n<<" = "<<k;
    
    return 0;
}
