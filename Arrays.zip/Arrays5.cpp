#include <iostream>
using namespace std;
 
int main()
{
    int arr[100];
    int size, i, j, temp;
    cout<<"Enter the number of elements of the array: ";
    cin>>size;
    cout<<"Enter the numbers "<<endl;
    for(i=0; i<size; i++)
    {
        cin>>arr[i];
    }
    for(i=0; i<size; i++)
    {
        for(j=i+1; j<size; j++)
        {
            if(arr[j] < arr[i])
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    cout<<"The numbers arranged in ascending order are given below"<<endl;
    for(i=0; i<size; i++)
    {
        cout<<arr[i]<<endl;
    }
 
    return 0;
}
