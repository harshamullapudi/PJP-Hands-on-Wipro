#include <iostream>
#include<bits/stdc++.h>
#include<cmath>
#include<vector>

using namespace std;
 
int main()
{
    int a,b;
    cout<<"Enter two positive integers:"<<endl;
    cin>>a;
    cin>>b;
    vector<int> v;
    for(int i=a;i<=b;i++){
        int count=0;
        for(int j=2;j<sqrt(i);j++){
            if(i%j==0)
            count++;
        }
        if(count==0)
        v.push_back(i);
    }
    cout<<"Prime numbers between "<<a<<" and "<<b<<" are: ";
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    
    return 0;
}
