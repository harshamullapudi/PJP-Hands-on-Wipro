#include <iostream>
#include<bits/stdc++.h>
#include<cmath>
#include<vector>

using namespace std;
void primenum(int n){
    vector<int> v;
    for(int i=2;i<=n;i++){
        int count=0;
        for(int j=2;j<=sqrt(i);j++){
            if(i%j==0)
            count++;
        }
        if(count==0)
        v.push_back(i);
    }
    for(int i=0;i<v.size();i++){
        for(int j=i;j<v.size();j++){
            if(v[i]+v[j]==n){
                cout<<n<<" = "<<v[i]<<" + "<<v[j]<<endl;
            }
        }
    }
    
    
}
 
int main()
{
    int n;
    cout<<"Enter a positive integer: ";
    cin>>n;
    primenum(n);
    
    return 0;
}
