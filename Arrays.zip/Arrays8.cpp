include <iostream>
#include<bits/stdc++.h>

using namespace std;
 
int main()
{
    int arr[5];
    cout<<"Enter the numbers "<<endl;
    for(int i=0; i<5; i++)
    {
        cin>>arr[i];
    }
    sort(arr,arr+5);
    int min;
    int k=0;
    for(int i=0;i<4;i++){
        for(int j=i+1;j<5;j++){
            if(arr[i]+arr[j]==arr[k]){
                k++;
            }
            else{
                min=arr[k];
                break;
            }
            
        }
    }
    cout<<min;
    
    return 0;
}
