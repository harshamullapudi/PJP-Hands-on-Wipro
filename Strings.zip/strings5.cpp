#include <iostream>
using namespace std;

void vowelstoZ(char* str){
    //int count = 0;
    while (*str != '\0') {
        if(*str=='a'||*str =='e'||*str =='i'||*str =='o'||*str =='u'){
            *str='z';
        }
        str++;
    } 
    
}

int main(){
    char str[50];
    //int length;
    cout << "\nEnter any string : ";
    cin >> str;
    vowelstoZ(str);
    cout<<str;
    return 0;
}

