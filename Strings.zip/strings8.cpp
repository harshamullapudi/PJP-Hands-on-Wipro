#include <iostream>
#include <bits/stdc++.h>
using namespace std;

void mystrrev(char* str1,char* str2){
    int len1=0;
    int k=0;
    for(int i=0;str1[i]!='\0';i++){
        len1++;
    }
    for(int i=len1-1;i>=0;i--){
        str2[k]=str1[i];
        k++;
    }
    cout<<str2;
}

int main(){
    char str1[50];
    char str2[50]="";
    cout << "\nEnter string: ";
    cin >> str1;
    mystrrev(str1,str2);
    
    return 0;
}

