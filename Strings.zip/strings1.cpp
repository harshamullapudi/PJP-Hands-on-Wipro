#include<iostream>
using namespace std;
 
int main() {
   string str_inp1;
   string str_inp2;
    
   cout<<"Enter the first string:\n";
   cin>>str_inp1;
   cout<<"Enter the second string 2:\n";
   cin>>str_inp2;
    
 
    if (str_inp1 == str_inp2) 
        cout <<"Entred strings are identical"<<endl; 
    else
        cout <<"Strings are not identical"<< endl; 
     
         
}
