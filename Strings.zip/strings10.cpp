#include <bits/stdc++.h>
using namespace std;
int main(int argc, char* argv[]){
    for(int i=1;i<argc;i++){
        cout<<argv[i]<<" ";
    }
    
    return 0;
}


//output in terminal

harsha@harsha-VirtualBox:~/H-Assignments$ g++ strings10.cpp -o main
harsha@harsha-VirtualBox:~/H-Assignments$ ./main "Hello World"
Hello World harsha@harsha-VirtualBox:~/H-Assignments$ 


