#include <iostream>
#include<bits/stdc++.h>
using namespace std;

int main ()
{
  char *ptr = "uvwxyzabc";
  cout << 2[ptr];
  cout << ptr[2];
  cout << *(ptr + 2);
}
//output: www
