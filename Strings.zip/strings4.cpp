#include <iostream>
using namespace std;

int mystrlen(char* str){
    int count = 0;
    while (*str != '\0') {
        count++;
        str++;
    } 
    return count;
}

int main(){
    char str[50];
    int length;
    cout << "\nEnter any string : ";
    cin >> str;
    length = mystrlen(str);
    cout << "\nThe length of the given string : " << length;
    cout << endl;
    return 0;
}

