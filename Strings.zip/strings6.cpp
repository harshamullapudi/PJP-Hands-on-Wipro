#include <iostream>
using namespace std;

int checkidentical(char* str1,char* str2){
    //int count = 0;
    while (*str1 != '\0' && *str2 != '\0') {
        if(*str1!=*str2){
            return 1;
            break;
        }
        
        *str1++;
        *str2++;
    } 
    return 0;
    
}

int main(){
    char str1[50];
    char str2[50];
    cout << "\nEnter 2 strings : ";
    cin >> str1;
    cin >> str2;
    int result=checkidentical(str1,str2);
    cout<<result;
    return 0;
}

