#include <bits/stdc++.h>
using namespace std;
int fun(char* s){
    int len=0;
    for(int i=0;s[i]!='\0';i++){
        len++;
    }
    return len;
}
int main(int argc, char* argv[]){
    char s[50]={argv[1]};
    int length=fun(s);
    cout<<length;
    
    return 0;
}
