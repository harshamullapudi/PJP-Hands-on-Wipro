
#include <bits/stdc++.h>
using namespace std;
int main(int argc, char* argv[]){
    if(argc==5){
        for(int i=1;i<argc;i++){
            cout<<argv[i]<<" ";
        }
    }
    else{
        cout<<"Invalid number of parametres. Pls try again";
    }
    
    return 0;
}

//output

harsha@harsha-VirtualBox:~/H-Assignments$ vi strings12.cpp
harsha@harsha-VirtualBox:~/H-Assignments$ g++ strings12.cpp -o main
harsha@harsha-VirtualBox:~/H-Assignments$ ./main 1 2 3 Hello
1 2 3 Hello harsha@harsha-VirtualBox:~/H-Assignments$ ./main 123 hello 1 3 4 yo
Invalid number of parametres. Pls try againharsha@harsha-VirtualBox:~/H-Assignments$ 
