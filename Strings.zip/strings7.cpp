#include <iostream>
#include <bits/stdc++.h>
using namespace std;

void mystrcat(char* str1,char* str2, char* str3){
    int len1=0;
    int len2=0;
    int k=0;
    for(int i=0;str1[i]!='\0';i++)
    len1++;
    for(int i=0;str2[i]!='\0';i++)
    len2++;
    
    for(int i=0;i<len1;i++){
        str3[k]=str1[i];
        k++;
    }
    for(int i=0;i<len2;i++){
        str3[k]=str2[i];
        k++;
    }
    cout<<str3;
}

int main(){
    char str1[50];
    char str2[50];
    char str3[50]="";
    cout << "\nEnter 2 strings : ";
    cin >> str1;
    cin >> str2;
    mystrcat(str1,str2,str3);
    
    return 0;
}

