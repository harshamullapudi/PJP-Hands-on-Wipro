#include <bits/stdc++.h>
#include<iostream>
using namespace std;
class Person{
    //cout<<"This is a person"<<endl;
};
class Student: public Person{
    public:
    int year;
    char course[20];
    char clgname[20];
    Student(int y, char* c1, char* c2){
        year=y;
        for(int i=0;i<20;i++){
            course[i]=c1[i];
        }
        for(int i=0;i<20;i++){
            clgname[i]=c2[i];
        }
    }
    ~Student();
};
class Employee: public Person{
    public:
    int eno;
    char dojoin[20];
    double salary;
    Employee(int eno1, char* d1, double k){
        eno=eno1;
        for(int i=0;i<20;i++){
            dojoin[i]=d1[i];
        }
        salary=k;
    }
    ~Employee();
};
int main(){
   
    return 0;
}



