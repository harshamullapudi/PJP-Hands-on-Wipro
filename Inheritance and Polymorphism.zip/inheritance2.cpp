/*
1. Inherited members of d1: pub_base_fun(), prot_base_fun(), pub_der1_fun(), prot_der1_fun(), priv_der1_var()

2. Inherited members of d2: pub_base_fun(), prot_base_fun(), pub_der2_fun(), prot_der2_fun(), priv_der2_var()
*/
