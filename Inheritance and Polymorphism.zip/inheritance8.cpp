/*  Here clearly Employee must be base class and Manager must be the derived class because the things like manager,assistant, clerk must ne derived from base employee class */

class Employee{
//
};

class Manager: public Employee{
//
};
