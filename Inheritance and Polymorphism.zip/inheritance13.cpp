#include<bits/stdc++.h>
#include<iostream>
using namespace std;

class Person{
    public:
    char name[20];
    public:
    string getName(){
        return name;
    }
    Person(char* names){
        for(int i=0;i<20;i++)
        name[i]=names[i];
        cout<<"Person constructor called"<<endl;
    }
};
class Participant: public Person{
    public:
    Participant(char* name): Person(name){
        cout<<"Participany constructor called"<<endl;
    }
};
int main(){
    Participant p1("Rahul");
    Participant p2("Arjun");
    p1=p2;
    cout<<p1.getName();
    
   return 0;
}

//output: Arjun
