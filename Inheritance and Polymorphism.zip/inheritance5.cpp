class Vehicles{
Vehicles(){
   cout<<"Vehicles Constructor called"<<endl;
}
};
class Four_Wheelers: public Vehicles{
Four_Wheelers(){
   cout<<"Four_Wheelers Constructor called"<<endl;
}
};
class Cars: public Four_Wheelers{
Cars(){
   cout<<"Cars Constructor called"<<endl;
}
};
class Sedan: public Cars{
Sedan(){
   cout<<"Sedan Constructor called"<<endl;
}
};
class SUV: public Cars{
SUV(){
   cout<<"SUV Constructor called"<<endl;
}
};
