class Vehicles{
//
};
class Four_Wheelers: public Vehicles{
//
};
class Cars: public Four_Wheelers{
//
};
class Sedan: public Cars{
//
};
class SUV: public Cars{
//
};
