#include<bits/stdc++.h>
#include<iostream>
using namespace std;

class Person{
    char name[20];
    public:
    string getName(){
        return name;
    }
    Person(char* names){
        for(int i=0;i<20;i++)
        name[i]=names[i];
        cout<<"Person constructor called";
    }
};
class Participant: public Person{
    int x;
    public:
    Participant(int x1): Person(name){
        x=x1;
    }
};
int main(){
   return 0;
}

//we cant call persons constructor because the variable in class person is private
