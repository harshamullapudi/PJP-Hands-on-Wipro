#include <iostream>
using namespace std;
class Shape{
    public:
    int l=3;
    int b=3;
    double computeArea(){
        return (double)l*b;
    }
};
class Rectangle: public Shape{
    public:
    int length=5;
    int breadth=5;
    double computerArea(){
        return (double)length*breadth;
    }
};
class Square: public Shape{
    public:
    int side=5;
    double computerArea(){
        return (double)side*side;
    }
};
class Circle: public Shape{
    public:
    int radius=5;
    double computerArea(){
        return (double)3.14*radius*radius;
    }
};
int main(){
    Square s;
    Rectangle r;
    Circle c;
    cout<<s.computerArea()<<endl;
    cout<<r.computerArea()<<endl;
    cout<<c.computerArea()<<endl;
    
    return 0;
}
