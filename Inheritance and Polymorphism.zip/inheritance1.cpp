//(a) 
class Number{
//
};
class Integer: public Number{
//
};
class FloatingPoint: public Number{
//
};
class Scientific: public Number{
//
};
class Fixed: public Number{
//
};



//(b)
class Animal{
//
};
class Domestic: public Animal{
//
};
class Dog: public Domestic,public Animal{
//
};
class Dalmation: public Animal,public Domestic,public Animal{
//
};



//(c)
class Furniture{
//
};
class Table: public Furniture{
//
};
class DiningTable: public Furniture,public Table{
//
}; 
class RoundShapedTable: public DiningTable, public Furniture, public Table{
//
};
class RectangleShapedTable: public DiningTable, public Furniture, public Table{
//
};



//(d)
class StorageDevices{
//
};
class Floppy{
//
};
class CD: public StorageDevices,public Floppy{
//
};
class MemoryStick: public StorageDevices{
//
};



























