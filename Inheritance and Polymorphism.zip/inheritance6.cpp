#include<bits/stdc++.h>
using namespace std;

class Sample{
    int intdata;
    string stringdata;
    public:
    Sample(int data, string d2){
        intdata=data;
        stringdata=d2;
    }
    int getInt(){
        return intdata;
    }
    string getString(){
        return stringdata;
    }
    char characterAt(int p){
        vector<char> v;
        stringstream ss(stringdata);
        while(ss){
            char ch;
            ss>>ch;
            v.push_back(ch);
        }
        return v[p];
        
    }
    int reverse(){
        int sum=0;
        while(intdata>0){
            int k=intdata%10;
            sum=sum*10+k;
            intdata/=10;
        }
        return sum;
        
    }
    
};
int main(){
    Sample s1(2021,"harsha");
    cout<<s1.characterAt(2)<<endl;
    cout<<s1.reverse();
}



