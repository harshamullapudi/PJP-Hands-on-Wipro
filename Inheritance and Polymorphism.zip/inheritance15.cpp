#include <iostream>
using namespace std;
class A
{
public:
  void display ()
  {
    cout << "A::display ";
}};
class D:public A
{
public:
  void display ()
  {
    cout << "D::display ";
}};

int
main ()
{
  A d = D ();
  d.display ();

  return 0;
}

//line 20 is changed
