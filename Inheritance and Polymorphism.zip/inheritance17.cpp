#include <iostream>
using namespace std;
class Shape{
    int l,b;
    public:
    double computeArea(){
        return (double)l*b;
    }
}
