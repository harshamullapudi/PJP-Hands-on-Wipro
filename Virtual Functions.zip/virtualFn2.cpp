//the objects of Cars,BMW and SUV can be passed to the function

//Vehicles and four_wheelers objects cant be passed
