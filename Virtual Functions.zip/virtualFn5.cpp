
#include <bits/stdc++.h>
using namespace std;
class Chart{
    public:
    char arr[20];
    virtual void plotchart()=0;
};
class PieChart:public Chart{
    public:
    void plotchart(){
        cout<<"piechart: "<<endl;;
    }
};
class BarChart:public Chart{
    public:
    void plotchart(){
       
        cout<<"barchart: "<<endl;;
    }
    
};


int main()
{
    PieChart p;
    p.plotchart();
    BarChart b;
    b.plotchart();
    return 0;
}

