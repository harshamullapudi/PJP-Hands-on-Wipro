
#include <bits/stdc++.h>
using namespace std;
class Shape{
    virtual void area()=0;
    virtual void perimeter()=0;
};
class Square:public Shape{
    public:
    int s;
    Square(int s1):s(s1){}
    void area(){
        int a=s*s;
        cout<<"area: "<<a<<endl;;
    }
    void perimeter(){
        int p=4*s;
        cout<<"perimeter: "<<p<<endl;;
    }
};
class Circle:public Shape{
    int r;
    public:
    Circle(int r1):r(r1){}
    void area(){
        int a=r*r*3.14;
        cout<<"area: "<<a<<endl;;
    }
    void perimeter(){
        int p=2*3.14*r;
        cout<<"perimeter: "<<p<<endl;;
    }
};
class Rectangle:public Shape{
    int l,b;
    public:
    Rectangle(int l1,int b1):l(l1),b(b1){}
    void area(){
        int a=l*b;
        cout<<"area: "<<a<<endl;;
    }
    void perimeter(){
        int p=2*(l+b);
        cout<<"perimeter: "<<p<<endl;;
    }
};


int main()
{
    Square s(2);
    s.area();
    s.perimeter();
    Circle c(2);
    c.area();
    c.perimeter();
    Rectangle r(2,3);
    r.area();
    r.perimeter();
    
    return 0;
}

