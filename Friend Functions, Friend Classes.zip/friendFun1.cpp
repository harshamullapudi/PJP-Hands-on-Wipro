#include <bits/stdc++.h>
using namespace std;
 class Date{
     private:
     int day;
     int month;
     int year;
     public:
     Date(){
         day=0;
         month=0;
         year=0;
     }
     Date(int day1,int month1,int year1){
         day=day1;
         month=month1;
         year=year1;
     }
     void print(){
         cout<<day<<"-"<<month<<"-"<<year<<endl;
     }
     friend Date operator+(Date &, Date &);
 };
 
 Date operator+(Date &d1, Date &d2){
     Date d3;
     d3.day=d1.day+d2.day;
     d3.month=d1.month+d2.month;
     d3.year=d1.year+d2.year;
     return d3;
     
 }
 int main(){
     Date d1(20,5,2000);
     Date d2(1,0,0);
     Date d3;
     d3=d1+d2;
     d3.print();
     return 0;
     
     
 }
