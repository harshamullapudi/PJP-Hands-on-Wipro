#include <bits/stdc++.h>
using namespace std;
class XYZ{
    int a;
    public:
    XYZ(int a=10){
        this->a=a;
    }
    void access(){
        
        
    }
    friend void test();
    
};
void test(){
    XYZ obj(20);
    obj.a=12;
    cout<<obj.a<<endl;
}
int main(){
    test();
    return 0;
}
