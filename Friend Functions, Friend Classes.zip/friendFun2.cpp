#include <bits/stdc++.h>
using namespace std;
 class String{
     private:
     string s;
     public:
     String(){
         s="";
     }
     String(string s1){
         s=s1;
     }
     void print(){
         cout<<s<<endl;
     }
     friend String operator+(String & ,String &);
 };
 
 String operator+(String &s1,String& s2){
     String s3;
     s3.s=s1.s+s2.s;
     s3.s=s2.s+s1.s;
     return s3;
 }
 int main(){
     String s1("yo");
     String s2("sample");
     String s3;
     s3=s2+s1;
     s3.print();
     return 0;
     
     
 }
