#include<bits/stdc++.h>
using namespace std;
class student{
  private:
  int admno;
  char sname[20];
  float eng,math,science;
  float total;
  float ctotal(){
      return (eng+math+science)/3;
  }
  public:
  void Readdata(int admno1, char* sname1, float eng1, float math1, float science1){
      admno=admno1;
      for(int i=0;i<20;i++){
          sname[i]=sname1[i];
      }
      eng=eng1;
      math=math1;
      science=science1;
      total=ctotal();
  }
  void display(){
      cout<<"Admission no: "<<admno<<endl;
      cout<<"Name "<<sname<<endl;
      cout<<"Eng: "<<eng<<endl;
      cout<<"Math: "<<math<<endl;
      cout<<"Science: "<<science<<endl;
      cout<<"Total: "<<total;
  }
  
};
int main(){
    student s;
    s.Readdata(7620, "harsha",9.5,9.5,9.5);
    s.display();
}
