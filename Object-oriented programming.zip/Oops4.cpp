#include<bits/stdc++.h>
using namespace std;
class BOOK{
  private:
  int BOOK_NO;
  char BOOKTITLE[20];
  float PRICE;
  float TOTAL_COST(int N){
      return N*PRICE;
  }
  public:
  void INPUT(int bookno,char* booktitle,float price){
      BOOK_NO=bookno;
      for(int i=0;i<20;i++){
      BOOKTITLE[i]=booktitle[i];
      }
      PRICE=price;
  }
  void PURCHASE(){
      int N;
      cout<<"Entere no of copies: ";
      cin>>N;
      cout<<TOTAL_COST(N);
  }
};
int main(){
    BOOK b;
    b.INPUT(5, "THINK LIKE A MONK",500.50);
    b.PURCHASE();
    return 0;
}
