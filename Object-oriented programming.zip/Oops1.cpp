#include <iostream>
#include <cstdlib>
using namespace std;
#define SIZE 10
class queue
{
    int *que;       // array to store queue elements
    int qsize;   // maximum capacity of the queue
    int idxfront;      // front points to the front element in the queue (if any)
    int idxrear;       // rear points to the last element in the queue
    int count;      // current size of the queue
 
public:
    queue(int size = SIZE);     // constructor
    ~queue();                   // destructor
 
    void Remove();
    void insert(int x);
    int peek();
    int size();
    bool isEmpty();
    bool isFull();
};
 
// Constructor to initialize a queue
queue::queue(int size)
{
    que = new int[size];
   qsize = size;
    idxfront = 0;
    idxrear = -1;
    count = 0;
}
//destructor
queue::~queue() {
    delete[] que;
}
void queue::Remove()
{
  
    if (isEmpty())
    {
        cout << "Underflow\nProgram Terminated\n";
        exit(EXIT_FAILURE);
    }
    cout <<"Removed: "<< que[idxfront] << endl;
    idxfront = (idxfront + 1) % qsize;
    count--;
}
void queue::insert(int item)
{
    if (isFull())
    {
        cout << "Overflow\nProgram Terminated\n";
        exit(EXIT_FAILURE);
    }
    cout << "Inserting " << item << endl;
    idxrear = (idxrear + 1) % qsize;
    que[idxrear] = item;
    count++;
}
int queue::peek()
{
    if (isEmpty())
    {
        cout << "Underflow\nProgram Terminated\n";
        exit(EXIT_FAILURE);
    }
    return que[idxfront];
}
int queue::size() {
    return count;
}
bool queue::isEmpty() {
    return (size() == 0);
}

bool queue::isFull() {
    return (size() == qsize);
}
 
int main()
{
    // creating a queue of capacity 5
    queue q(5);
    cout<<"Size of queue: "<<q.size()<<endl;
    q.insert(8);
    q.insert(12);
    q.insert(17);
    q.insert(25);
    q.Remove();
    q.Remove();
    q.Remove();
    q.insert(30);
    cout<<"Size of queue: "<<q.size()<<endl;
    q.Remove();
    q.Remove();
    cout<<"Size of queue: "<<q.size()<<endl;
 
    
    return 0;
}
