class Rect{
    float tx,ty,bx,by;
    public:
    float GetWidth(){
        return by;
    }
    float GetHeight(){
        return tx;
    }
    void setWidth(float width){
        by=width;
    }
    void setHeight(float height){
        tx=height;
    }
};
