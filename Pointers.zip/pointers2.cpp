#include <stdio.h>
#include <bits/stdc++.h>
using namespace std;

void fun(int* arr){

    for(int i=9;i>=0;i--){
        cout<<arr[i]<<" ";
    }
}
int main()
{
    int arr[10];
    //int ar[10];
    for(int i=0;i<10;i++){
        cin>>arr[i];
    }
    fun(arr);
    return 0;
}

