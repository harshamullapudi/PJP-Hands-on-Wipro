#include <iostream>
using namespace std;

const char *fun(const char *s1, const char *s2)
{
    int k = 0;
    const char *w = NULL;
    while(*s1 != '\0')
    {
        if(*s1 == *s2)
        {
            while(*s2 != '\0')
            {
                if(*s2 != *s1)
                {
                    k = 0;
                    break;
                }
                else
                {
                    k = 1;
                    if(w == NULL)
                    {
                        w = s1;
                    }
                }
                s2++;
                s1++;
            }
        }
        if(k == 1)
        return w;
        
        s1++;
    }
    return NULL;
    
}

int main() {
	// your code goes here
	const char *s1,*s2;
	char a[100],b[100];
	cin>>a;
	cin>>b;
	s1 = a;
	s2 = b;
	const char *e = fun(s1,s2);
	int count = 0;
	int k=0;
	while(b[k] != '\0')
	{
	    count++;
	    k++;
	}
	for(int i = 0; i < count; i++)
	{
	    cout<<*e;
	    e++;
	}
	return 0;
}