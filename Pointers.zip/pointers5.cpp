
#include <bits/stdc++.h>
using namespace std;

int n = 20;
int main ()
{
  int *ptr = &n;
  cout << *ptr;
  (*ptr)++;
  cout << *ptr;
  return 0;
}

//output: 2021
