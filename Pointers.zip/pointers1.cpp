
#include <stdio.h>
#include <bits/stdc++.h>
using namespace std;

void fun(int* arr, int* ar){
    int size=sizeof(arr[0]);
    cout<<10*size<<endl;
    
    for(int i=0;i<10;i++){
        ar[i]=arr[i];
    }
    
    for (int i = 0; i < 9; i++) {
  
        for (int j = i + 1; j < 10; j++) {
  
            if (ar[j]< ar[i]) {
  
                int t = ar[i];
                ar[i] = ar[j];
                ar[j] = t;
            }
        }
    }
    
    for(int i=0;i<10;i++){
        cout<<ar[i]<<" ";
    }
    
    
}


int main()
{
    int arr[10];
    int ar[10];
    for(int i=0;i<10;i++){
        cin>>arr[i];
    }
    fun(arr,ar);
    
    

    return 0;
}

