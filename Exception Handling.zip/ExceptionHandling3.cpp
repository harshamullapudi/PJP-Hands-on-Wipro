//question incomplete
