
#include <bits/stdc++.h>
using namespace std;
class  String{
    char A[10];
    public:
   String(){
       A[0]='\0';
   }
   ~String(){}
    String(char *k){
        strcpy(A,k);
    }
    void Display(){
        cout<<A<<endl;
    }
    char operator[](int n){
            try{
                if(n>=sizeof(A)){
                    throw n;
                }
            }
            catch(int e){
                cout<<"Array out of bounds exception "<<e<<endl;
            }
        return A[n];
    }
};

int main()
{
    char arr[]="harsha7620";
    String st(arr);
    cout<<st[12]<<endl;
    st.Display();
    return 0;
}

