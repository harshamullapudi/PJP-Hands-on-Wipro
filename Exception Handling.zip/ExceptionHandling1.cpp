
#include <bits/stdc++.h>
using namespace std;

int main()
{
    int d,n1,n2;
    cin>>n1;
    cin>>n2;
    try{
        if(n2==0){
            throw n2;
        }
        d=n1/n2;
    }
    catch(int e){
        cout<<"Arthemtic Exception: "<<e<<endl;;
    }
    cout<<"The division is "<<d<<endl;

    return 0;
}

