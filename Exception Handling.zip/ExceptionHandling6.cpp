
#include <bits/stdc++.h>
using namespace std;
class  String{
    int A[10];
    public:
   String(){
       A[0]=0;
   }
   ~String(){}
    String(int *k){
       for(int i=0;i<10;i++){
           A[i]=k[i];
       }
    }
    void Display(){
        for(int i=0;i<10;i++){
           cout<<A[i]<<" ";
       }
    }
    int operator[](float n){
        
        try{
            if(isdigit(n)==false){
                throw n;
            }
            
        }
        catch(float e){
                cout<<"This is not integer: "<<e<<endl;
            }
            return 0;
    }
    int operator[](char n){
        try{
            if(isdigit(n)==false){
                throw n;
            }
            
        }
        catch(char e){
                cout<<"This is not integer: "<<e<<endl;
            }
            return 0;
        
    }
    int operator[](int n){
            try{
                if(n>=sizeof(A)){
                    throw n;
                }
            }
            catch(int e){
                cout<<"Array out of bounds exception "<<e<<endl;
            }
        return A[n];
    }
};

int main()
{
    int arr[]={3,6,8,3,7,9,3,9,5,8};
    String st(arr);
    float a=7.8;
    char ch='p';
    int q=6;
    cout<<st[a]<<endl;
    cout<<st[ch]<<endl;
    cout<<st[q]<<endl;
    st.Display();
    return 0;
}

