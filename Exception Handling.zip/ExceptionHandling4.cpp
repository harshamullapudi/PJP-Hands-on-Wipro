
#include <bits/stdc++.h>
using namespace std;
class  Vector{
    int A[10];
    public:
    Vector(){
        for(int i=0;i<10;i++){
            A[i]=0;
        }
    }
    Vector(int v1[]){
        for(int i=0;i<10;i++){
            A[i]=v1[i];
        }
    }
    friend Vector operator/(Vector, Vector );
        
};
Vector operator/(Vector v1,Vector v2){
        Vector v3;
        for(int i=0;i<10;i++){
            try{
                if(v1.A[i]==0){
                    throw v1.A[i];
               }
               v3.A[i]=v2.A[i]/v1.A[i];
        
               }
               catch(int e){
                   cout<<"Arthematic Exception: "<<e<<endl;
               }
               cout<<v3.A[i]+" ";
        }
}
int main()
{
   int v1[]={1,2,3,4,5,6,7,8,9,10};
   int v2[]={1,2,3,4,5,6,7,8,9,0};
    Vector vec1(v1);
    Vector vec2(v2);
    Vector vec3;
    vec3=vec2/vec1;
    cout<<"Done";
    return 0;
}

