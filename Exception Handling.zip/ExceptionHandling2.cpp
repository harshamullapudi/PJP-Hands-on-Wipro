
#include <bits/stdc++.h>
using namespace std;

#define size 10

int main()
{
    int A[size];
    
    try{
        for(int i;;i++){
            if(i<0||i>=size){
                throw i;
            }
        }
        
    }
    catch(int e){
        cout<<"Out of bounds Exception: "<<e<<endl;;
    }
    cout<<"Done "<<endl;

    return 0;
}

