#include<bits/stdc++.h>
using namespace std;
//1

class Point{
   public:
   Point(){
       //code
   }
};

//2
class Queue{
   public:
   Queue(){
       //code
   }
};

//3
class Employee{
   public:
   Employee(){
       //code
   }
};
