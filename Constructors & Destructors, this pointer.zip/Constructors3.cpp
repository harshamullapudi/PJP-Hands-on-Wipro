#include<bits/stdc++.h>
using namespace std;

class Date{
  Date CopyDate(Date d){   //here default constructor is called
     Date d1=d;            //here copy constructor is called
     return d1;
}


};
