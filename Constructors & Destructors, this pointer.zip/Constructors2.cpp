#include <iostream>
#include <cstdlib>
using namespace std;
#define SIZE 10
class queue
{
    int *que;       // array to store queue elements
    int qsize;   // maximum capacity of the queue
    int idxfront;      // front points to the front element in the queue (if any)
    int idxrear;       // rear points to the last element in the queue
    int count;      // current size of the queue
 
public:
    queue(int size = SIZE);     // constructor
    ~queue();                   // destructor
 
    void Remove();
    void insert(int x);
    int peek();
    int size();
    bool isEmpty();
    bool isFull();
};
 
// Constructor to initialize a queue
queue::queue(int size)
{
    que = new int[size];
    qsize = size;
    idxfront = 0;
    idxrear = -1;
    count = 0;
}
//destructor
queue::~queue() {
    delete[] que;
}
int main()
{
    // creating a queue of capacity 5
    queue q(5);
    
    return 0;
}
