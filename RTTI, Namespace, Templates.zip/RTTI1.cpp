#include <bits/stdc++.h>
using namespace std;
class Number{
    virtual void type(){};
};
class Integer: public Number{
    void type(){
        cout<<"Integer type."<<endl;
    }
};
void check(Number* num){
    Integer* intp=dynamic_cast<Integer*>(num);
    if(intp){
        cout<<"Integer class Object"<<endl;
    }
    else{
        cout<<"Number class Object"<<endl;
    }
}
int main(){
    Number* nums=new Number;
    Integer* ints=new Integer;
    check(nums);
    check(ints);
    return 0;
}