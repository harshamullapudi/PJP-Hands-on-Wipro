#include <bits/stdc++.h>
using namespace std;
class Base{};
class Der1: public Base{};
int main(){
    Der1 dobj;
    Base & bref=dobj;
    Base bobj;
    Base* bptr=&dobj;
    if(typeid(bref)==typeid(dobj)){
        cout<<"True 1"<<endl;
    }
    if(typeid(bobj)==typeid(dobj)){
        cout<<"True 2"<<endl;
    }
    if(typeid(*bptr)==typeid(dobj)){
        cout<<"True 3"<<endl;
    }

}
//none of the assertions are true