#include <bits/stdc++.h>
using namespace std;
template<class T>
class Vector{
    private:
    T *A;
    int n;
    public:
    Vector(T* arr){
        A=new int[10];
        n=10;
        for(int i=0;i<10;i++){
            A[i]=arr[i];
        }
    }
    Vector(T* arr, int a){
        A=new T[a];
        n=a;
        for(int i=0;i<a;i++){
            A[i]=arr[i];
        }
        for(int i=0;i<a;i++){
            cout<<A[i]<<" ";
        }
        cout<<endl;
    }
    T sum();
    T max();
    T min();
    void sort();
    ~Vector();
   
};
template<class T>
T Vector<T>::sum(){
    T sum=0;
    for(int i=0;i<n;i++){
        sum+=A[i];
    }
    return sum;
}
template<class T>
T Vector<T>::max(){
    T max=A[0];
    for(int i=0;i<n;i++){
       if(A[i]>max) max=A[i];
    }
    return max;
}
template<class T>
T Vector<T>::min(){
    T min=A[0];
    for(int i=0;i<n;i++){
       if(A[i]<min) min=A[i];
    }
    return min;
}
template<class T>
Vector<T>::~Vector(){
    delete[] A;
}

template<class T>
void Vector<T>::sort(){
    for(int i=0;i<n-1;i++){
        for(int j=i;j<n;j++){
            if(A[i]>A[j]){
                T temp=A[i];
                A[i]=A[j];
                A[j]=temp;
            }
        }
    }
    for(int i=0;i<n;i++){
        cout<<A[i]<<" ";
    }
    cout<<endl;
}
int main(){
    int iarr[]={10, 4, 7, 5, 2};
    double darr[]={2.5, 1.8, 8.4, 0.5, 6.3};
    Vector<int> v1(iarr, 5);
    Vector<double> v2(darr, 5);
    cout<<"sum: "<<v1.sum()<<endl;
    cout<<"Max: "<<v1.max()<<endl;
    cout<<"Min: "<<v1.min()<<endl;
    v1.sort();
    cout<<"sum: "<<v2.sum()<<endl;
    cout<<"Max: "<<v2.max()<<endl;
    cout<<"Min: "<<v2.min()<<endl;
    v2.sort();

}