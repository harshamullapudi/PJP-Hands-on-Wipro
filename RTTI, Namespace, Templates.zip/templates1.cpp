#include <bits/stdc++.h>
using namespace std;
template<typename T>
void swap(T a, T b){
    T temp=a;
    a=b;
    b=temp;
    cout<<a<<" "<<b<<endl;
}
int main(){
    swap<int>(2, 5);
    swap<char>('c', 'p');
    swap<double>(6.4, 8.2);
    return 0;
}