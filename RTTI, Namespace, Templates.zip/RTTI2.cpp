#include <bits/stdc++.h>
using namespace std;
class Vehicle{
    virtual void check(){}
};
class Fourwheeler: public Vehicle{};
class Car: public Fourwheeler{};
main(){
    Vehicle* vptr=new Car;
    Fourwheeler* fptr=dynamic_cast<Fourwheeler*>(vptr);
    if(fptr) cout<<"yes1"<<endl;
    // Fourwheeler* fptr=new Fourwheeler;
    // Car* cptr=dynamic_cast<Car*>(fptr);
    // if(cptr) cout<<"yes2"<<endl;
    // Fourwheeler* fptr=new Fourwheeler;
    // Vehicle* vptr=dynamic_cast<Vehicle*>(fptr);
    // if(vptr) cout<<"yes3"<<endl;
    return 0;
}

//dynamic cast of cptr dosent work.