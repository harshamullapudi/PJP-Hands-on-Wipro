#include <bits/stdc++.h>
using namespace std;
class Shape{
    virtual void type(){}
};
class Rectangle: public Shape{};
class Circle: public Shape{};
class Triangle: public Shape{};
int main(){
    map<string,int> m;
    Rectangle r1;
    m[typeid(r1).name()]++;
    Rectangle r2;
    m[typeid(r2).name()]++;
    Circle c1;
    m[typeid(c1).name()]++;
    Triangle t1;
    m[typeid(t1).name()]++;
    Triangle t2;
    m[typeid(t2).name()]++;
    Triangle t3;
    m[typeid(t3).name()]++;
    cout<<m["9Rectangle"]<<" rectangle objects"<<endl;
    cout<<m["6Circle"]<<" circle objects"<<endl;
    cout<<m["8Triangle"]<<" triangle objects"<<endl;

}