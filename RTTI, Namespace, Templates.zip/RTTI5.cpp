#include <bits/stdc++.h>
using namespace std;
int main(){
    int a;
    char b;
    char* pc;
    char buf[100];
    cout<<typeid(a).name()<<endl;
    cout<<typeid(b).name()<<endl;
    cout<<typeid(&b).name()<<endl;
    cout<<typeid(pc).name()<<endl;
    cout<<typeid(buf).name()<<endl;
}
//i  -integer
//c  -char
//Pc -pointer to char array
//Pc -pointer to char array
//A100_c -char array with size 100