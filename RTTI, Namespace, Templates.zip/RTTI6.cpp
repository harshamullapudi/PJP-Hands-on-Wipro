#include <bits/stdc++.h>
using namespace std;
class Base{};
class Der: public Base{};
int main(){
    Der* dptr;
    Base* bptr;
    if(typeid(bptr)==typeid(dptr)){
        cout<<"identical"<<endl;
    }
    else{
        cout<<"different"<<endl;
    }
}
//different