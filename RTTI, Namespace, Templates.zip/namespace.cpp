#include <bits/stdc++.h>
using namespace std;

namespace ns{
    int x;
}
int main(){
    int x=9;
    using namespace ns;
    x=20;
    cout<<x;
}
//20
//question incomplete