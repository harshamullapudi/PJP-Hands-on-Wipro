#include <bits/stdc++.h>
using namespace std;
template<class T>
void swap(T *a, T *b){
    T *temp=*a;
    *a=*b;
    *b=*temp;
}
template<class T>
void sort(T *arr,T n){
    for(int i=0;i<n-1;i++){
        for(int j=i;j<n;j++){
            if(arr[i]>arr[j]){
                swap(arr[i], arr[j]);
            }
        }
    }
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main(){
    int iarr[]={10, 4, 7, 5, 2};
    char carr[]={'f', 'w', 'a', 'r', 'u'};
    double darr[]={2.5, 1.8, 8.4, 0.5, 6.3};
    sort<int>(iarr, 5);
    sort<char>(carr, 5);
    sort<double>(darr, 5);
    return 0;
}