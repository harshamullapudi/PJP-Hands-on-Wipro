#include <bits/stdc++.h>
using namespace std;

struct data{
    char c;
    int x;
};


int main(){
    
    cout<<sizeof(struct data);

    return 0;
}
//1. 8



#include <bits/stdc++.h>
using namespace std;

struct data{
    char arrr[10];
    int x;
};


int main(){
    
    cout<<sizeof(struct data);

    return 0;
}
//2. 16




#include <bits/stdc++.h>
using namespace std;

struct data{
    char arrr[10];
    long int x;
};


int main(){
    
    cout<<sizeof(struct data);

    return 0;
}
//3. 24





#include <bits/stdc++.h>
using namespace std;

struct data{
    char arrr[100];
    int x;
};


int main(){
    
    cout<<sizeof(struct data);

    return 0;
}
//4. 104
