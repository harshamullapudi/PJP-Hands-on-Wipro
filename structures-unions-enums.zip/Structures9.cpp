#include <bits/stdc++.h>
#pragma pack(1)
using namespace std;

struct data{
    char c;
    int x;
};


int main(){
    
    cout<<sizeof(struct data);

    return 0;
}
//1. 5




#include <bits/stdc++.h>
#pragma pack(1)
using namespace std;

struct data{
    char arrr[10];
    int x;
};


int main(){
    
    cout<<sizeof(struct data);

    return 0;
}
//2. 14



#include <bits/stdc++.h>
#pragma pack(1)
using namespace std;

struct data{
    char arrr[10];
    long int x;
};


int main(){
    
    cout<<sizeof(struct data);

    return 0;
}
//3. 18




#include <bits/stdc++.h>
#pragma pack(1)
using namespace std;

struct data{
    char arrr[100];
    int x;
};


int main(){
    
    cout<<sizeof(struct data);

    return 0;
}
//4. 104
