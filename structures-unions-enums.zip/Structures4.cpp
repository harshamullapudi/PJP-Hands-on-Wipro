
#include <bits/stdc++.h>
using namespace std;

struct BATSMAN{
    char name[100];
    int age;
    int highest_score;
    int least_score;
    int no_of_ducks;
};

void printData(BATSMAN* s)
{
    for(int i=0;i<3;i++){
    cout << "batsman name: " << s[i].name<< endl;
    cout << "batsman age: " << s[i].age << endl;
    cout << "highest score: " << s[i].highest_score << endl;
    cout << "least score" << s[i].least_score << endl;
    cout << "no of ducks" << s[i].no_of_ducks << endl;
    }
    
}
int main(){
    struct BATSMAN s[3];
    
    cout<<"Enter students info: \n";
    for(int i=0;i<3;i++){
        cout<<"enter batsman name: ";
        cin>>s[i].name;
        cout<<"enter batsman age ";
        cin>>s[i].age;
        cout<<"enter highest score: ";
        cin>>s[i].highest_score;
        cout<<"enter least score: ";
        cin>>s[i].least_score;
        cout<<"enter no of ducks: ";
        cin>>s[i].no_of_ducks;
    }

    printData(s);
    return 0;
}
