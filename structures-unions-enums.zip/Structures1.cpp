
#include <bits/stdc++.h>
using namespace std;

struct EMP{
    char emp_name[50];
    int emp_id;
    int emp_age;
    float emp_salary;
};

EMP ReceiveEmpInfo(EMP);
void DisplayEmpInfo(EMP & e);

int main()
{
    EMP e[3];

    for (int i = 0; i < 3; i++)
    {
        cout << "Enter the data for the number " << i+1 << "employee" << endl;

        EMP e[3];
        e[i] = ReceiveEmpInfo(e[3]);
    }

    cout << "now" << endl << endl;

    for (int i = 0; i < 3; i++)
    {
        EMP e[3];
        DisplayEmpInfo(e[i]);
    }
    cout<<"the size of struct EMP is : "<<sizeof(struct EMP);

    return 0;
}


EMP ReceiveEmpInfo(EMP e)
{
    cout << "Enter employee name ";
    cin>>e.emp_name;

    cout << "Enter the employee ID: ";
    cin>>e.emp_id;

    cout << "Enter the employee age: ";
    cin>>e.emp_age;

    cout << "Enter the employee salary: ";
    cin >>e.emp_salary;

    cout << endl << endl;

    return e;
}

void DisplayEmpInfo(EMP &e)
{
    cout << "employee name: " << e.emp_name<< endl;
    cout << "employee ID: " << e.emp_id << endl;
    cout << "employee age: " << e.emp_age << endl;
    cout << "employee salary" << e.emp_salary << endl;
    
    return ;
}




