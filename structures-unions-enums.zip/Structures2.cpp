
#include <bits/stdc++.h>
using namespace std;

struct student{
    char student_name[100];
    int roll_no;
    int mark1;
    int mark2;
    int mark3;
    double avg;
}s[10];
int main(){
    cout<<"Enter students info: \n";
    for(int i=1;i<=5;i++){
        cout<<"enter student name: ";
        cin>>s[i].student_name;
        cout<<"enter student roll no: ";
        cin>>s[i].roll_no;
        cout<<"enter student mark1: ";
        cin>>s[i].mark1;
        cout<<"enter student mark2: ";
        cin>>s[i].mark2;
        cout<<"enter student mark3: ";
        cin>>s[i].mark3;
    }

    for(int i=1;i<=5;i++){
        s[i].avg=(s[i].mark1+s[i].mark2+s[i].mark3)/3;
    }
    double min=s[1].avg;
    double max=s[5].avg;
    int min1=1;
    int max1=5;
    for(int i=1;i<=5;i++){
        if(s[i].avg>max){
            max1=i;
        }
    }
    for(int i=1;i<=5;i++){
        if(s[i].avg<min){
            min1=i;
        }
    }
    
    cout<<"name of person with highest average is: "<<s[max1].student_name<<endl;
    cout<<"name of person with lowest average is: "<<s[min1].student_name<<endl;
    return 0;
}
