
#include <bits/stdc++.h>
using namespace std;

struct DATA{
    int num1;
    int num2;
    int num3;
    int average;
};

DATA calculateAvg(DATA har ){
    har.average=(har.num1+har.num2+har.num3)/3;
    return har;
}

int main(){
    struct DATA har;
    
    cout<<"Enter student mark1: ";
    
        cin>>har.num1;
        cout<<"enter student mark2: ";
        cin>>har.num2;
        cout<<"enter student mark3: ";
        cin>>har.num3;
        har=calculateAvg(har);
        
        cout<<har.average;

    
    return 0;
}
