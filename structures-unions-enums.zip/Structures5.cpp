
#include <bits/stdc++.h>
using namespace std;

struct EMP{
    char emp_name[50];
    int emp_id;
    int emp_age;
    float emp_salary;
};

int main(){
    struct EMP e1;;
    
    cout<<"Enter students info: \n";
        cout << "Enter employee name ";
    cin>>e1.emp_name;

    cout << "Enter the employee ID: ";
    cin>>e1.emp_id;

    cout << "Enter the employee age: ";
    cin>>e1.emp_age;

    cout << "Enter the employee salary: ";
    cin >>e1.emp_salary;
    
    
    struct EMP *eptr=&e1;
    cout<<"Employee name: "<<eptr->emp_name<<endl;;
    cout<<"Employee id: "<<eptr->emp_id<<endl;
    cout<<"employee age: "<<eptr->emp_age<<endl;
    cout<<"employee salary: "<<eptr->emp_salary<<endl;
       
    return 0;
}
