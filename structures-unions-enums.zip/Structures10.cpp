
#include <bits/stdc++.h>
using namespace std;

struct s_memo{
    int nVal;
    char cVal;
};
union u_memo{
    int nVal;
    char cVal;
};



int main(){
    struct s_memo s_memo_1;
    union u_memo u_memo_1;
    
    cout<<"Enter nVal of struct: ";
    cin>>s_memo_1.nVal;
    cout<<"Enter cVal of struct: ";
    cin>>s_memo_1.cVal;
    cout<<"nVal of struct: "<<s_memo_1.nVal<<endl;
    cout<<"cVal of struct: "<<s_memo_1.cVal<<endl;
    cout<<"Enter nVal of union: ";
    cin>>u_memo_1.nVal;
    cout<<"nVal of union: "<<u_memo_1.nVal<<endl;
    cout<<"Enter cVal of union: ";
    cin>>u_memo_1.cVal;
    cout<<"cVal of union: "<<u_memo_1.cVal<<endl;
    
   
    cout<<"Size of struct: "<<sizeof(struct s_memo)<<endl;
    cout<<"Size of union: "<<sizeof(union u_memo)<<endl;

    return 0;
}


/*output:
Enter nVal of struct: 5                                                                           
Enter cVal of struct: a                                                                           
nVal of struct: 5                                                                                 
cVal of struct: a                                                                                 
Enter nVal of union: 6                                                                            
nVal of union: 6                                                                                  
Enter cVal of union: b                                                                            
cVal of union: b                                                                                  
Size of struct: 8                                                                                 
Size of union: 4 
*/
