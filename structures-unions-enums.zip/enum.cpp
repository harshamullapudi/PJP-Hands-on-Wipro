
#include <bits/stdc++.h>
using namespace std;

enum WEEK{sunday, monday, tuesday, wednesday, thursday, friday, saturday};



int main(){
    int DailyWeight[7];
    for(int i=sunday;i<=saturday;i++){
        cout<<"Enter weight on day"<<i<<" : ";
        cin>>DailyWeight[i];
    }
    cout<< "Weight for tuesday: "<<DailyWeight[tuesday]<<endl;
    cout<< "Weight for thursday: "<<DailyWeight[thursday]<<endl;

    return 0;
}
